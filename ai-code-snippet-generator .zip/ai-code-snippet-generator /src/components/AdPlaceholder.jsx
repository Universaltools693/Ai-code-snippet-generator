function AdPlaceholder() {
  return (
    <div className="ad-placeholder" style={{ height: '90px', lineHeight: '90px' }}>
      Ad Space
    </div>
  );
}

export default AdPlaceholder;
